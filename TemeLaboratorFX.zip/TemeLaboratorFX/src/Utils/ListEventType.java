package Utils;

public enum ListEventType {
    ADD, REMOVE, UPDATE
}
