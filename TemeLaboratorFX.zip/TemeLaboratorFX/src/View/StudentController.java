package View;

import Domain.Student;
import Service.ServiceStudent;
import Utils.ListEvent;
import Utils.Observer;
import Validare.ValidationException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class StudentController implements Observer<Student> {
    private ServiceStudent serviceStudent;
    private ObservableList<Student> model;
    private StudentView view;

    public StudentController(ServiceStudent serviceStudent){

        this.serviceStudent = serviceStudent;
        model= FXCollections.observableArrayList( serviceStudent.getList());

    }

    @Override
    public void notifyEvent(ListEvent<Student> e) {
        model.setAll(StreamSupport.stream(e.getList().spliterator(), false).collect(Collectors.toList()));
    }

    public ObservableList<Student> getModel(){
        return model;
    }

    public void setView(StudentView studentView) {
        this.view=studentView;
    }


    public void showStudentDetails(Student newValue) {
        if(newValue!=null){
            view.idStudentField.setText(String.valueOf(newValue.getId()));
            view.numeField.setText(newValue.getNume());
            view.grupaField.setText(newValue.getGrupa());
            view.emailField.setText(newValue.getEmail());
            view.cadruDidacticField.setText(newValue.getCadruDidactic());
        }
    }
    



    private void showErrorStudent(String message) {
        Alert text=new Alert(Alert.AlertType.ERROR);
        text.setTitle("Mesaj de eroare");
        text.setContentText(message);
        text.showAndWait();
    }

    public void handleAddStudent(ActionEvent actionEvent) {
        int id= Integer.parseInt(view.idStudentField.getText());
        String nume=view.numeField.getText();
        String grupa=view.grupaField.getText();
        String email=view.emailField.getText();
        String cadruDidactic=view.cadruDidacticField.getText();
        try{
            serviceStudent.add(id,nume,grupa,email,cadruDidactic);
        } catch (ValidationException e) {
            showErrorStudent(e.getMessage());
        }
    }

    public void handleDeleteStudent(ActionEvent actionEvent) {
        Student st = view.tableView.getSelectionModel().getSelectedItem();
        if (st != null) {
            try {
                serviceStudent.delete(st.getId());
            } catch (ValidationException e) {
                showErrorStudent(e.getMessage());
            }
        }
    }

    public void handleUpdateStudent(ActionEvent actionEvent) {
        int id= Integer.parseInt(view.idStudentField.getText());
        String nume=view.numeField.getText();
        String grupa=view.grupaField.getText();
        String email=view.emailField.getText();
        String cadruDidactic=view.cadruDidacticField.getText();
        try{
            serviceStudent.update(id,nume,grupa,email,cadruDidactic);
        } catch (ValidationException e) {
            showErrorStudent(e.getMessage());
        }
    }

    public void handleClear(ChoiceBox<String> choiceBox){
        String choice=choiceBox.getValue();
        if(choice.equals("ClearAll")){
        view.idStudentField.clear();
        view.numeField.clear();
        view.grupaField.clear();
        view.emailField.clear();
        view.cadruDidacticField.clear();}
        else  if(choice.equals("ClearId")){
            view.idStudentField.clear();
        }
        else  if(choice.equals("ClearNume")){
            view.numeField.clear();
        }
        else  if(choice.equals("ClearGrupa")){
            view.grupaField.clear();
        }
        else  if(choice.equals("ClearEmail")){
            view.emailField.clear();
        }
        else  if(choice.equals("ClearCadruDidactic")){
            view.cadruDidacticField.clear();
        }
    }


    /* public void handleClearAll(ActionEvent actionEvent){
        view.idStudentField.clear();
        view.numeField.clear();
        view.grupaField.clear();
        view.emailField.clear();
        view.cadruDidacticField.clear();
    }*/
}
