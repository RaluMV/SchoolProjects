package View;


import Domain.Student;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.image.ImageView;

import java.io.File;


public class StudentView {
    private StudentController studentController;
    private BorderPane borderPane;
    TableView<Student> tableView=new TableView<>();
    ChoiceBox<String> choiceBox=new ChoiceBox<>();

    //textField
    TextField idStudentField=new TextField();
    TextField numeField=new TextField();
    TextField grupaField=new TextField();
    TextField emailField=new TextField();
    TextField cadruDidacticField=new TextField();

    //button
    Button addButton=new Button("ADD");
    Button deleteButton=new Button("DELETE");
    Button updateButton=new Button("UPDATE");
    Button clearButton=new Button("CLEAR");


    //constructor
    public StudentView(StudentController studentController) {
        this.studentController = studentController;
        initView();
    }
    private void initView(){

        borderPane=new BorderPane();
        borderPane.setRight(initRight());
        borderPane.setLeft(initLeft());
        borderPane.setBottom(initBottom());

    }

    public AnchorPane initRight(){
        AnchorPane rightPane=new AnchorPane();
        //gridPane
        GridPane gridPane=new GridPane();
        gridPane.add(createLabel("Id Student"),0,0);
        gridPane.add(createLabel("Nume Student"),0,1);
        gridPane.add(createLabel("Grupa Student"),0,2);
        gridPane.add(createLabel("Email Student"),0,3);
        gridPane.add(createLabel("Cadru Didactic "),0,4);

        gridPane.add(idStudentField,1,0);
        gridPane.add(numeField,1,1);
        gridPane.add(grupaField,1,2);
        gridPane.add(emailField,1,3);
        gridPane.add(cadruDidacticField,1,4);


        ColumnConstraints columnConstraints1=new ColumnConstraints();
        columnConstraints1.setPrefWidth(100d);

        ColumnConstraints columnConstraints2=new ColumnConstraints();
        columnConstraints2.setPrefWidth(200d);

        gridPane.getColumnConstraints().addAll(columnConstraints1,columnConstraints2);

        rightPane.getChildren().add(gridPane);

        //style button
        addButton.setStyle("-fx-font: 16 arial; -fx-base: #ef1010;");
        deleteButton.setStyle("-fx-font: 16 arial; -fx-base: #ef1010;");
        updateButton.setStyle("-fx-font: 16 arial; -fx-base: #ef1010;");
        clearButton.setStyle("-fx-font: 16 arial; -fx-base: #ef1010;");

        //horizontal box
        HBox hBox=new HBox();
        hBox.getChildren().addAll(addButton,deleteButton,updateButton,clearButton);
        addButton.setOnAction(studentController::handleAddStudent);
        deleteButton.setOnAction(studentController::handleDeleteStudent);
        updateButton.setOnAction(studentController::handleUpdateStudent);

        //choiceBox
        choiceBox.getItems().add("ClearAll");
        choiceBox.getItems().add("ClearId");
        choiceBox.getItems().add("ClearNume");
        choiceBox.getItems().add("ClearGrupa");
        choiceBox.getItems().add("ClearEmail");
        choiceBox.getItems().add("ClearCadruDidactic");
        choiceBox.setValue("ClearAll");
        rightPane.getChildren().addAll(hBox,choiceBox);



        AnchorPane.setTopAnchor(gridPane,20d);
        AnchorPane.setRightAnchor(gridPane,20d);
        AnchorPane.setBottomAnchor(hBox,200d);
        AnchorPane.setRightAnchor(hBox,20d);
        AnchorPane.setRightAnchor(choiceBox,20d);
        AnchorPane.setBottomAnchor(choiceBox,100d);
        clearButton.setOnAction((ActionEvent e) ->studentController.handleClear(choiceBox));


        return rightPane;
    }

    private Label createLabel(String s) {
        Label label=new Label(s);
        label.setFont(new Font(12));
        label.setTextFill(Color.RED);
        label.setStyle("-fx-text-box-border: red");
        return label;


    }

    public AnchorPane initLeft(){
        AnchorPane leftPane=new AnchorPane();

        TableColumn<Student,String> columnIdStudent=new TableColumn<>("Id");
        TableColumn<Student,String> columnNume=new TableColumn<>("Nume");
        TableColumn<Student,String> columnGrupa=new TableColumn<>("Grupa");
        TableColumn<Student,String> columnEmail=new TableColumn<>("Email");
        TableColumn<Student,String> columnCadruDidactic=new TableColumn<>("Cadru Didactic");
        tableView.getColumns().addAll(columnIdStudent,columnNume,columnGrupa,columnEmail,columnCadruDidactic);

        columnIdStudent.setCellValueFactory(new PropertyValueFactory<Student,String>("Id"));
        columnNume.setCellValueFactory(new PropertyValueFactory<Student,String>("Nume"));
        columnGrupa.setCellValueFactory(new PropertyValueFactory<Student,String>("Grupa"));
        columnEmail.setCellValueFactory(new PropertyValueFactory<Student,String>("Email"));
        columnCadruDidactic.setCellValueFactory(new PropertyValueFactory<Student,String>("CadruDidactic"));

        tableView.setItems(studentController.getModel());
        tableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Student>() {
            @Override
            public void changed(ObservableValue<? extends Student> observable, Student oldValue, Student newValue) {
                studentController.showStudentDetails(newValue);
            }
        });
        leftPane.getChildren().add(tableView);
        AnchorPane.setTopAnchor(tableView,20d);
        return leftPane;





    }
    public AnchorPane initBottom(){
        AnchorPane topPane=new AnchorPane();
        ImageView imageView=new ImageView(new File("st.jpg").toURI().toString());
        imageView.setFitHeight(200);
        imageView.setFitWidth(400);
        topPane.getChildren().add(imageView);
        return topPane;
    }


    public BorderPane getView() {
        return borderPane;
    }
}
