package services;

public interface IDonationServer {
}
