package services;

/**
 * 
 */
public interface IDonationObserverServer {

    /**
     * 
     */
    public void notifyFromServer();

}