package observer;

import java.util.*;

/**
 * 
 */
public interface IMedicObserver {

    /**
     * @return
     */
    public void notifyMedic();

}