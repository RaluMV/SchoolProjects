package controllers;

import observer.IMedicObserver;
import service.MedicClientService;

import java.util.*;

/**
 * 
 */
public class StergeCerereController implements IMedicObserver {

    /**
     * Default constructor
     */
    public StergeCerereController() {
    }

    /**
     * 
     */
    private MedicClientService medicController;

    /**
     * @param service 
     * @return
     */
    public void setClientService(MedicClientService service) {
        // TODO implement here

    }

    /**
     * @return
     */
    public void stergeCerere() {
        // TODO implement here

    }

    @Override
    public void notifyMedic() {

    }
}