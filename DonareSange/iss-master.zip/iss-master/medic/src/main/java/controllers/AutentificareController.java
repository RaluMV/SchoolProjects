package controllers;

import service.MedicClientService;

import java.util.*;

/**
 * 
 */
public class AutentificareController {

    /**
     * Default constructor
     */
    public AutentificareController() {
    }

    /**
     * 
     */
    private MedicClientService medicController;

    /**
     * @return
     */
    public void login() {
        // TODO implement here

    }

    /**
     * @return
     */
    public void register() {
        // TODO implement here

    }

    /**
     * @param service 
     * @return
     */
    public void setClientService(MedicClientService service) {
        // TODO implement here

    }

}