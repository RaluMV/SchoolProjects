package observer;

/**
 * 
 */
public interface IDonationObserver {
    void notifyDonor();

}