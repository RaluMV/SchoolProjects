package observer;

import java.util.*;

/**
 * 
 */
public interface IAdministratorObserver {

    /**
     * 
     */
    public void notifyAdmin();

}