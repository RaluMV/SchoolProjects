package domain;

public class Centru {
    Locatie location;

    public Locatie getLocation() {
        return location;
    }

    public void setLocation(Locatie location) {
        this.location = location;
    }
}
