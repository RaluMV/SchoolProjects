package domain;

import java.util.*;

/**
 * 
 */
public class Punga {

    /**
     * Default constructor
     */
    public Punga() {
    }

    /**
     * 
     */
    private int idDonator;

    /**
     * 
     */
    private string RH;

    /**
     * 
     */
    private Enum grupaSange;

    /**
     * 
     */
    private float trombocite;

    /**
     * 
     */
    private float leucocite;

    /**
     * 
     */
    private float globuleRosii;

    /**
     * 
     */
    private float plasma;




    /**
     * 
     */
    public void getIdDonator() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getRH() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getGrupaSange() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getTrombocite() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getLeucocite() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getGlobuleRosii() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getPlasma() {
        // TODO implement here
    }

}