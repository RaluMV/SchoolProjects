package domain;

import java.util.*;

/**
 * 
 */
public class Locatie {

    /**
     * Default constructor
     */
    public Locatie() {
    }

    /**
     * 
     */
    private String address;

    /**
     * 
     */
    private String city;

    /**
     * 
     */
    private String county;

    /**
     * @return
     */
    public String getAddress() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getCity() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getCounty() {
        // TODO implement here
        return "";
    }

    /**
     * @param value 
     * @return
     */
    public void setAddress(String value) {
        // TODO implement here
        return null;
    }

    /**
     * @param value 
     * @return
     */
    public void setCity(String value) {
        // TODO implement here
        return null;
    }

    /**
     * @param value 
     * @return
     */
    public void setCounty(String value) {
        // TODO implement here
        return null;
    }

}