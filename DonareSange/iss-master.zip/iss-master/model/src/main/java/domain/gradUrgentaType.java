package domain;

/**
 * 
 */
public enum gradUrgentaType {
    ridicat,
    mediu,
    scazut
}