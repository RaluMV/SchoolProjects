package domain;

/**
 * 
 */
public enum grupaSangeType {
    O,
    A,
    B,
    AB
}