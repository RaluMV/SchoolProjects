package observer;

import java.util.*;

/**
 * 
 */
public interface ICentruObserver {

    /**
     * 
     */
    void notifyFromServer();

}